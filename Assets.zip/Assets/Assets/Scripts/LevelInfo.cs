﻿public class LevelInfo
{
    public string Id { get; set; }
    public string Name { get; set; }
    /*
     * public double Attempts { get; set; }
     * public float Rating { get; set; }
     * public Double Highscore { get; set; }
     * public string BgMusic { get; set; }
     * public string Theme { get; set; }
     */
    public string Creator { get; set; }
    public string BgColor { get; set; }
    public string Objects { get; set; }
}

