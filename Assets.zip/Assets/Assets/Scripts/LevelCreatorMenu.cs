﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using Microsoft.WindowsAzure.MobileServices;
using System;
using System.Threading.Tasks;
using System.Linq;
using UnityEngine.UI;
using System.Text.RegularExpressions;

static class Globals
{
    // global int 
    public static string Name;
    public static string Creator;
    public static string BgColor;
    public static string Objects;
    public static string Text;
    public static string WantedLevel;
    public static string WantedLevelName;
    public static List<GameObject> obs;
    public static string objectType;
    public static GameObject temp;
    public static Vector3 scale;
    public static bool create;
}
public class LevelCreatorMenu : MonoBehaviour
{
    [SerializeField]
    private InputField nameInputField;
    [SerializeField]
    private Text objectTypeField;
    [SerializeField]
    private InputField wantedInputField;
    [SerializeField]
    private InputField nameField;
    [SerializeField]
    private Text outputField;
    [SerializeField]
    private Text toggleText;
    [SerializeField]
    private Camera camera;


    // Start is called before the first frame update
    void Start()
    {
        Globals.Name = "Default";
        Globals.Creator = "Default";
        Globals.BgColor = "Default";
        Globals.Objects = "";
        Globals.obs = new List<GameObject>();
        Globals.objectType = "Cube";
        Globals.temp = GameObject.CreatePrimitive(PrimitiveType.Cube);
        Globals.scale = new Vector3(1.0f, 1.0f, 1.0f);
        Globals.create = false;
       
    }
    public void EnterNameButtonClicked()
    {
        Globals.Name = nameInputField.text;
        nameInputField.text = "";
        TextboxUpdate();
    }
    public void EnterCreatorNameButtonClicked()
    {
        Globals.Creator = nameInputField.text;
        nameInputField.text = "";
        TextboxUpdate();
    }
    public void EnterBackgroundColorButtonClicked()
    {
        Globals.BgColor = nameInputField.text;
        nameInputField.text = "";
        if(SceneManager.GetActiveScene().name == "BuildScene2"){
            string[] colors = Globals.BgColor.Split(',');
            if (colors.Length == 3)
            {
                float r = float.Parse(colors[0]);
                float g = float.Parse(colors[1]);
                float b = float.Parse(colors[2]);
                Image img = GameObject.Find("Menu Panel").GetComponent<Image>();
                img.color = new Color(r, g, b, 1.0f);
            }
        }
        else{
            nameInputField.text = "Need 3 floats for background color";
        }
        TextboxUpdate();
    }
    public void ChangeObject()
    {
        if(Globals.objectType == "Cube"){
            Globals.objectType = "Sphere";
        }
        else{
            Globals.objectType = "Cube";
        }
        objectTypeField.text = "Current Object Type: " + Globals.objectType;
    }
    public void AddRandomObjectButtonClicked()
    {
        int type = UnityEngine.Random.Range(0,2);
        float x = UnityEngine.Random.Range(-300.0f, 1000.0f);
        float y = UnityEngine.Random.Range(-150.0f, 700.0f);
        float z = UnityEngine.Random.Range(-100.0f, 100.0f);
        float rotx = UnityEngine.Random.Range(-360.0f, 360.0f);
        float roty = UnityEngine.Random.Range(-360.0f, 360.0f);
        float rotz = UnityEngine.Random.Range(-360.0f, 360.0f);
        float scalex = UnityEngine.Random.Range(0.0f, 3.0f) * 100;
        float scaley = UnityEngine.Random.Range(0.0f, 3.0f) * 100;
        float scalez = UnityEngine.Random.Range(0.0f, 3.0f) * 100;;
        Globals.Objects = Globals.Objects + "[" + type.ToString() + ";" + x.ToString() + "," + y.ToString() + "," + z.ToString() + ";" + rotx.ToString() + "," + roty.ToString() + "," + rotz.ToString()+ ";" + scalex.ToString() + "," + scaley.ToString() + "," + scalez.ToString() +  "]";
        TextboxUpdate();
    }
    public void ExitButtonClicked()
    {
        Application.Quit();
    }
    public async void SaveButtonClicked()
    {
        if(Globals.Name == "Default" || Globals.Creator == "Default"){
            outputField.text = "Level must not have Default as creator or name";
            return;
        }
        if(SceneManager.GetActiveScene().name == "BuildScene2"){
            for (int i = 0; i < Globals.obs.Count; i++){
                int type = 0;
                if(Globals.obs[i].name == "Sphere"){
                    type = 1;
                }
                Globals.Objects = Globals.Objects + "[" + type.ToString() + ";" + Globals.obs[i].transform.position.x.ToString() + "," + Globals.obs[i].transform.position.y.ToString() + "," + Globals.obs[i].transform.position.z.ToString() + ";1,1,1;" + Globals.obs[i].transform.localScale.x.ToString() + "," + Globals.obs[i].transform.localScale.y.ToString() + "," + Globals.obs[i].transform.localScale.z.ToString() + "]";
            }
        }
        try
        {
            var table = AzureMobileServiceClient.Client.GetTable<LevelInfo>();
            var allEntries = await TestToListAsync(table);
            var initialCount = allEntries.Count();
            Debug.Log("Got count");
            await table.InsertAsync(new LevelInfo { Name = Globals.Name, Creator = Globals.Creator, BgColor = Globals.BgColor, Objects = Globals.Objects });
            Debug.Log("Inserted: " + Globals.Name + " " + Globals.Creator + " " + Globals.BgColor + " " + Globals.Objects);
            allEntries = await TestToListAsync(table);
            var newCount = allEntries.Count();

            Debug.Assert(newCount == initialCount + 1, "InsertAsync failed!");
        }
        catch(Exception){
            throw;
        }
    }
    public async void findIDs()
    {
        Globals.WantedLevelName = nameField.text;
        Debug.Log("Getting Ids for " + Globals.WantedLevelName);
        nameField.text = "";
        try
        {
            var table = AzureMobileServiceClient.Client.GetTable<LevelInfo>();
            var allEntries = await TestToListAsync(table);
            Debug.Log("Got table");
            int found = 0;
            foreach (LevelInfo lvl in allEntries)
            {
                if (lvl.Name.ToLower().Equals(Globals.WantedLevelName.ToLower()))
                {
                    nameField.text = nameField.text + (found + 1).ToString() + ".'" + Globals.WantedLevelName + "' By: " + lvl.Creator + ". ID = " + lvl.Id + '\n';
                    found++;
                }
            }
            if (found == 0)
            {
                nameField.text = "No levels of that name were found";
            }
        }
        catch (Exception)
        {
            throw;
        }
    }
    public async void DownloadButtonClicked()
    {
        Globals.WantedLevel = wantedInputField.text;
        wantedInputField.text = "";
        Debug.Log("Searching for level: " + Globals.WantedLevel);
        try
        {
            var table = AzureMobileServiceClient.Client.GetTable<LevelInfo>();
            var allEntries = await TestToListAsync(table);
            Debug.Log("Got table. Searching...");
            foreach (LevelInfo lvl in allEntries)
            {
                if (lvl.Id.Equals(Globals.WantedLevel))
                {
                    Debug.Log("Found it");
                    Globals.Name = lvl.Name;
                    Globals.Creator = lvl.Creator;
                    Globals.BgColor = lvl.BgColor;
                    Globals.Objects = lvl.Objects;
                    TextboxUpdate();
                    return;
                }
            }
            wantedInputField.text = "Level ID not found";
            Debug.Log("Level ID was invalid");
            return;
        }
        catch(Exception)
        {
            throw;
        }
    }
    private async Task<List<LevelInfo>> TestToListAsync(IMobileServiceTable<LevelInfo> table)
    {
        try
        {
            var allEntries = await table.ToListAsync();
            Debug.Assert(allEntries != null, "ToListAsync failed!");
            return allEntries;
        }
        catch (Exception)
        {

            throw;
        }
    }
    public void TextboxUpdate(){
        outputField.text = "Current Level String: " + Globals.Name + " " + Globals.Creator + " " + Globals.BgColor + " " + Globals.Objects;
    }
    public void ClearButtonClicked(){
        Globals.Name = "Default";
        Globals.Creator = "Default";
        Globals.BgColor = "Default";
        Globals.Objects = "";
        TextboxUpdate();
    }
    public void buildMenuSceneButtonClicked(){
        SceneManager.LoadScene("BuildScene");
    }
    public void buildMenuSceneButton2Clicked()
    {
        SceneManager.LoadScene("BuildScene2");
    }
    public void loadMenuSceneButtonClicked()
    {
        SceneManager.LoadScene("LoadScene");
    }
    public void mainMenuSceneButtonClicked()
    {
        SceneManager.LoadScene("MainMenuScene");
    }
    public void DualMenuSceneButtonClicked()
    {
        SceneManager.LoadScene("FinishedScene");
    }
    public void Undo()
    {
        Destroy(Globals.obs.ElementAt(Globals.obs.Count - 1));
        Globals.obs.RemoveAt(Globals.obs.Count - 1);
    }
    public void toggleCreation()
    {
        Globals.create = !Globals.create;
        toggleText.text = "Object Creation: " + Globals.create;

    }
    public void SetScale()
    {
        string input = nameInputField.text;
        string[] scales = input.Split(',');

        if(scales.Length != 3){
            nameInputField.text = "Need 3 values for scale";
            return;
        }
        try{
            float xs = float.Parse(scales[0]);
            float ys = float.Parse(scales[1]);
            float zs = float.Parse(scales[2]);
            Globals.temp.transform.localScale = new Vector3(xs, ys, zs);
            Debug.Log("Scale set to " + xs.ToString() + "," + ys.ToString() + "," + zs.ToString());
            nameInputField.text = "";
        }
        catch (Exception){
            Debug.Log("Failed to parse");
            nameInputField.text = "";
            return;
        }
    }
    public async void LoadLevel()
    {
        for (int i = 0; i < Globals.obs.Count; i++){
            Destroy(Globals.obs[i]);
        }
        Globals.WantedLevel = wantedInputField.text;
        Debug.Log("Searching for level: " + Globals.WantedLevel);
        try
        {
            var table = AzureMobileServiceClient.Client.GetTable<LevelInfo>();
            var allEntries = await TestToListAsync(table);
            Debug.Log("Got table. Searching...");
            foreach (LevelInfo lvl in allEntries)
            {
                if (lvl.Id.Equals(Globals.WantedLevel))
                {
                    Debug.Log("Found it");
                    Globals.Name = lvl.Name;
                    Globals.Creator = lvl.Creator;
                    Globals.BgColor = lvl.BgColor;
                    Globals.Objects = lvl.Objects;
                    string[] colors = lvl.BgColor.Split(',');
                    if(colors.Length == 3){
                        float r = float.Parse(colors[0]);
                        float g = float.Parse(colors[1]);
                        float b = float.Parse(colors[2]);
                        Image img = GameObject.Find("Menu Panel").GetComponent<Image>();
                        img.color = new Color(r, g, b, 1.0f);
                    }
                    string[] objects = Globals.Objects.Split(']');
                    int objectcount = objects.Length - 1;
                    wantedInputField.text = "'" + Globals.Name + "', by " + Globals.Creator + '\n' + objectcount + " objects in scene";
                    Debug.Log("Loading " + objectcount + " items");
                    for (int i = 0; i < objects.Length - 1; i++)
                    {
                        //Debug.Log("String " + i.ToString() + objects[i]);
                        string[] parameters = objects[i].Split(';');
                        parameters[0] = Regex.Replace(parameters[0], "[^.0-9]", "");
                        //Debug.Log(parameters[1]);
                        string[] xyz = parameters[1].Split(',');
                        parameters[2] = Regex.Replace(parameters[2], "[^,.0-9]", "");
                        //Debug.Log(parameters[2]);
                        string[] rot = parameters[2].Split(',');
                        string[] scales = parameters[3].Split(',');
                        //Debug.Log(parameters[3]);
                        if (parameters[0] == "0"){
                            //Debug.Log("Building Cube");
                            GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
                            float x = float.Parse(xyz[0]);
                            float y = float.Parse(xyz[1]);
                            float xs = float.Parse(scales[0]);
                            float ys = float.Parse(scales[1]);
                            cube.transform.position = new Vector3(x, y, 40.0f);
                            cube.transform.localScale = new Vector3(xs, ys, 100);
                            cube.GetComponent<Renderer>().material.color = new Color(0.5f, 0.5f, 0.5f, 1.0f);
                            //cube.transform.rotation = rot;
                            Globals.obs.Add(cube);
                            //Debug.Log("Cube " + i + " at " + x + "," + y + " with scale of " + xs + "," + ys);
                        }
                        else{
                            GameObject sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            float x = float.Parse(xyz[0]);
                            float y = float.Parse(xyz[1]);
                            float xs = float.Parse(scales[0]);
                            float ys = float.Parse(scales[1]);
                            sphere.transform.position = new Vector3(x, y, 40.0f);
                            sphere.transform.localScale = new Vector3(xs , ys , 100);
                            sphere.GetComponent<Renderer>().material.color = new Color(0.5f, 0.5f, 0.5f, 1.0f);
                            //sphere.transform.rotation = rot;
                            Globals.obs.Add(sphere);
                            //Debug.Log("Sphere " + i + " at " + x + "," + y + " with scale of " + xs + "," + ys);
                        }
                    }
                    return;
                }
            }
            wantedInputField.text = "Level ID not found";
            Debug.Log("Level ID was invalid");
            return;
        }
        catch (Exception)
        {
            throw;
        }
    }
    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Clicked();
        }
    }
    void Clicked()
    {
        if(SceneManager.GetActiveScene().name != "BuildScene2"){
            return;
        }
        Vector3 screenPoint = Input.mousePosition;
        screenPoint.z = 1000.0f; //distance of the plane from the camera
        Globals.temp.transform.position = camera.ScreenToWorldPoint(screenPoint);
        Vector3 copy = Globals.temp.transform.position;
        copy.z = 40.0f;
        Globals.temp.transform.position = copy;
        //Debug.Log(Globals.temp.transform.position.x.ToString() + "," + Globals.temp.transform.position.y.ToString() + "," + Globals.temp.transform.position.z.ToString());
        if(Globals.create && Globals.temp.transform.position.x < 1000){
            //int type = 0;
            if(Globals.objectType == "Cube"){
                GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
                cube.transform.position = Globals.temp.transform.position;
                cube.transform.localScale = Globals.temp.transform.localScale*100;
                cube.GetComponent<Renderer>().material.color = new Color(0.5f, 0.5f, 0.5f, 1.0f);
                //cube.transform.localScale = cube.transform.localScale / 100;
                Globals.obs.Add(cube);
            }
            else{
                GameObject sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                sphere.transform.position = Globals.temp.transform.position;
                sphere.transform.localScale = Globals.temp.transform.localScale*100;
                sphere.GetComponent<Renderer>().material.color = new Color(0.5f, 0.5f, 0.5f, 1.0f);
                //sphere.transform.localScale = sphere.transform.localScale / 100;
                Globals.obs.Add(sphere);
                //type = 1;
            }
            //Globals.Objects = Globals.Objects + "[" + type.ToString() + ";" + Globals.temp.transform.position.x.ToString() + "," + Globals.temp.transform.position.y.ToString() + "," + Globals.temp.transform.position.z.ToString() + ";" + Globals.temp.transform.eulerAngles.x.ToString() + "," + Globals.temp.transform.eulerAngles.y.ToString() + "," + Globals.temp.transform.eulerAngles.z.ToString() + ";" + Globals.temp.transform.localScale.x.ToString() + "," + Globals.temp.transform.localScale.y.ToString() + "," + Globals.temp.transform.localScale.z.ToString() + "]";
            //TextboxUpdate();
        }
    }
}
